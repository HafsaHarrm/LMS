<?php
/**
 * Run this file ONCE from a browser or CLI after importing lms.sql,
 * e.g.  http://localhost/lms/database/seed_passwords.php
 * It sets a real, working bcrypt hash for the 3 demo accounts so
 * you can log in immediately with password: password123
 */
require_once __DIR__ . '/../config/db.php';

$hash = password_hash('password123', PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE email IN
    ('admin@ledger.edu','instructor@ledger.edu','student@ledger.edu')");
$stmt->bind_param('s', $hash);

if ($stmt->execute()) {
    echo "Demo account passwords set successfully.<br>";
    echo "You can now log in with:<br>";
    echo "admin@ledger.edu / password123<br>";
    echo "instructor@ledger.edu / password123<br>";
    echo "student@ledger.edu / password123<br>";
    echo "<br><strong>Delete this file after running it once.</strong>";
} else {
    echo "Error: " . $conn->error;
}

$stmt->close();
$conn->close();
