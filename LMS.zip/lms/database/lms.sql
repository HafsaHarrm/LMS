-- =========================================================
-- Ledger LMS - Database Schema
-- Import this file in MySQL Workbench (Server > Data Import
-- or File > Run SQL Script) to create and seed the database.
-- =========================================================

CREATE DATABASE IF NOT EXISTS lms_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE lms_db;

-- ---------------------------------------------------------
-- Users: admins, instructors and students in one table,
-- differentiated by the `role` column.
-- ---------------------------------------------------------
CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(120)  NOT NULL,
  email         VARCHAR(150)  NOT NULL UNIQUE,
  password      VARCHAR(255)  NOT NULL,
  role          ENUM('admin','instructor','student') NOT NULL DEFAULT 'student',
  avatar_color  VARCHAR(7)    DEFAULT '#1B2A4A',
  status        ENUM('active','suspended') NOT NULL DEFAULT 'active',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Courses: owned by an instructor
-- ---------------------------------------------------------
CREATE TABLE courses (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  instructor_id   INT NOT NULL,
  title           VARCHAR(180) NOT NULL,
  description     TEXT,
  category        VARCHAR(80) DEFAULT 'General',
  cover_color     VARCHAR(7) DEFAULT '#2D6E5E',
  status          ENUM('draft','published','archived') NOT NULL DEFAULT 'published',
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Enrollments: student <-> course, many-to-many
-- ---------------------------------------------------------
CREATE TABLE enrollments (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  student_id    INT NOT NULL,
  course_id     INT NOT NULL,
  progress      TINYINT UNSIGNED NOT NULL DEFAULT 0,
  enrolled_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_enrollment (student_id, course_id),
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Lessons / Modules: ordered content inside a course
-- ---------------------------------------------------------
CREATE TABLE lessons (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  course_id     INT NOT NULL,
  title         VARCHAR(180) NOT NULL,
  content       TEXT,
  video_url     VARCHAR(400),
  file_path     VARCHAR(300),
  position      INT NOT NULL DEFAULT 1,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Lesson completion tracking (drives progress %)
-- ---------------------------------------------------------
CREATE TABLE lesson_completions (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  student_id    INT NOT NULL,
  lesson_id     INT NOT NULL,
  completed_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_completion (student_id, lesson_id),
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Assignments: created by instructor for a course
-- ---------------------------------------------------------
CREATE TABLE assignments (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  course_id     INT NOT NULL,
  title         VARCHAR(180) NOT NULL,
  instructions  TEXT,
  due_date      DATE,
  max_points    INT DEFAULT 100,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Submissions: student answers to an assignment
-- ---------------------------------------------------------
CREATE TABLE submissions (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  assignment_id   INT NOT NULL,
  student_id      INT NOT NULL,
  file_path       VARCHAR(300),
  notes           TEXT,
  grade           INT DEFAULT NULL,
  feedback        TEXT,
  submitted_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  graded_at       TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY unique_submission (assignment_id, student_id),
  FOREIGN KEY (assignment_id) REFERENCES assignments(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Announcements: instructor -> enrolled students
-- ---------------------------------------------------------
CREATE TABLE announcements (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  course_id     INT NOT NULL,
  title         VARCHAR(180) NOT NULL,
  body          TEXT NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =========================================================
-- Seed data
-- Default password for ALL seeded accounts is:  password123
-- (hashed below with PHP password_hash / bcrypt)
-- =========================================================
INSERT INTO users (full_name, email, password, role, avatar_color) VALUES
('Ada Okafor',      'admin@ledger.edu',      '$2y$10$5DZ8VvKq0m0oQ2z7pQ0m8O0m5N1nQe2b1c1H1jH1x1v1b1n1m1p1e', 'admin',      '#1B2A4A'),
('Marcus Wei',       'instructor@ledger.edu', '$2y$10$5DZ8VvKq0m0oQ2z7pQ0m8O0m5N1nQe2b1c1H1jH1x1v1b1n1m1p1e', 'instructor', '#2D6E5E'),
('Priya Nandan',     'student@ledger.edu',    '$2y$10$5DZ8VvKq0m0oQ2z7pQ0m8O0m5N1nQe2b1c1H1jH1x1v1b1n1m1p1e', 'student',    '#C4442C');

-- NOTE: the bcrypt hashes above are placeholders and will NOT
-- validate. Run database/seed_passwords.php once after import
-- (see README) to set real, working password hashes safely.

INSERT INTO courses (instructor_id, title, description, category, cover_color) VALUES
(2, 'Introduction to Web Development', 'Learn HTML, CSS and JavaScript fundamentals from the ground up.', 'Programming', '#2D6E5E'),
(2, 'Database Design Essentials',       'Understand relational schemas, normalization and SQL querying.', 'Data', '#1B2A4A');

INSERT INTO enrollments (student_id, course_id, progress) VALUES
(3, 1, 40),
(3, 2, 0);

INSERT INTO lessons (course_id, title, content, position) VALUES
(1, 'HTML Basics', 'Structure of an HTML document, tags, attributes and semantic elements.', 1),
(1, 'CSS Fundamentals', 'Selectors, the box model, flexbox and responsive layout.', 2),
(1, 'JavaScript Essentials', 'Variables, functions, DOM manipulation and events.', 3),
(2, 'Entity-Relationship Modeling', 'Entities, attributes, relationships and cardinality.', 1),
(2, 'Normalization', '1NF, 2NF, 3NF and why they matter.', 2);

INSERT INTO assignments (course_id, title, instructions, due_date, max_points) VALUES
(1, 'Build a Personal Portfolio Page', 'Create a single HTML/CSS page introducing yourself. Submit the .html file.', '2026-08-15', 100),
(2, 'Design a Library Database Schema', 'Draft an ER diagram for a library system with at least 4 entities.', '2026-08-20', 100);
