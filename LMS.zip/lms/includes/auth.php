<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function current_role() {
    return $_SESSION['role'] ?? null;
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: ' . base_url('index.php'));
        exit;
    }
}

function require_role($role) {
    require_login();
    if (current_role() !== $role) {
        header('Location: ' . base_url('index.php'));
        exit;
    }
}

/**
 * Builds a relative link back to the project root regardless of which
 * sub-folder (admin/instructor/student) the current script lives in.
 */
function base_url($path = '') {
    // Depth is 1 for files inside admin/ instructor/ student/, 0 for root
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
    $inSubfolder = preg_match('#/(admin|instructor|student)/#', $script);
    $prefix = $inSubfolder ? '../' : '';
    return $prefix . $path;
}

function e($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function flash($key, $message = null) {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}
