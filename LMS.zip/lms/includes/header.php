<?php
// Expects $page_title (string) and $active (string key) to be set by the including page.
$role = current_role();
$name = $_SESSION['name'] ?? '';
$avatar_color = $_SESSION['avatar_color'] ?? '#1B2A4A';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($page_title ?? 'Ledger LMS') ?></title>
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">
    <div class="brand">Ledger<span>LMS</span></div>
    <nav>
      <?php if ($role === 'admin'): ?>
        <a href="<?= base_url('admin/dashboard.php') ?>" class="<?= $active === 'dashboard' ? 'active' : '' ?>">&#9635; Dashboard</a>
        <a href="<?= base_url('admin/manage_users.php') ?>" class="<?= $active === 'users' ? 'active' : '' ?>">&#9782; Users</a>
        <a href="<?= base_url('admin/manage_courses.php') ?>" class="<?= $active === 'courses' ? 'active' : '' ?>">&#9776; Courses</a>
      <?php elseif ($role === 'instructor'): ?>
        <a href="<?= base_url('instructor/dashboard.php') ?>" class="<?= $active === 'dashboard' ? 'active' : '' ?>">&#9635; Dashboard</a>
        <a href="<?= base_url('instructor/courses.php') ?>" class="<?= $active === 'courses' ? 'active' : '' ?>">&#128214; My Courses</a>
        <a href="<?= base_url('instructor/submissions.php') ?>" class="<?= $active === 'submissions' ? 'active' : '' ?>">&#9998; Grading</a>
      <?php elseif ($role === 'student'): ?>
        <a href="<?= base_url('student/dashboard.php') ?>" class="<?= $active === 'dashboard' ? 'active' : '' ?>">&#9635; Dashboard</a>
        <a href="<?= base_url('student/browse_courses.php') ?>" class="<?= $active === 'browse' ? 'active' : '' ?>">&#128269; Browse Courses</a>
        <a href="<?= base_url('student/my_courses.php') ?>" class="<?= $active === 'mycourses' ? 'active' : '' ?>">&#128214; My Courses</a>
        <a href="<?= base_url('student/assignments.php') ?>" class="<?= $active === 'assignments' ? 'active' : '' ?>">&#9998; Assignments</a>
      <?php endif; ?>
    </nav>
    <div class="role-tag">
      <div class="avatar" style="background:<?= e($avatar_color) ?>; margin-bottom:8px;"><?= e(initials($name)) ?></div>
      <div class="name"><?= e($name) ?></div>
      <div class="role"><?= e($role) ?></div>
    </div>
    <a href="<?= base_url('logout.php') ?>" class="logout-link" style="display:block; padding:10px 12px;">&#10140; Log out</a>
  </aside>
  <main class="main">
