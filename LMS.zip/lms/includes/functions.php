<?php
require_once __DIR__ . '/../config/db.php';

/** Return the two-letter initials used in the avatar badges */
function initials($name) {
    $parts = preg_split('/\s+/', trim($name));
    $upper = function_exists('mb_strtoupper') ? 'mb_strtoupper' : 'strtoupper';
    $sub = function_exists('mb_substr') ? 'mb_substr' : 'substr';
    $letters = array_map(fn($p) => $upper($sub($p, 0, 1)), $parts);
    return implode('', array_slice($letters, 0, 2));
}

/** Recalculate and persist a student's progress % for a course */
function recalc_progress($conn, $student_id, $course_id) {
    $total = 0; $done = 0;

    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM lessons WHERE course_id = ?");
    $stmt->bind_param('i', $course_id);
    $stmt->execute();
    $total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();

    if ($total > 0) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM lesson_completions lc
            JOIN lessons l ON l.id = lc.lesson_id
            WHERE lc.student_id = ? AND l.course_id = ?");
        $stmt->bind_param('ii', $student_id, $course_id);
        $stmt->execute();
        $done = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
        $stmt->close();
    }

    $progress = $total > 0 ? (int)round(($done / $total) * 100) : 0;

    $stmt = $conn->prepare("UPDATE enrollments SET progress = ? WHERE student_id = ? AND course_id = ?");
    $stmt->bind_param('iii', $progress, $student_id, $course_id);
    $stmt->execute();
    $stmt->close();

    return $progress;
}

function time_ago($datetime) {
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . 'm ago';
    if ($diff < 86400) return floor($diff / 3600) . 'h ago';
    if ($diff < 604800) return floor($diff / 86400) . 'd ago';
    return date('M j, Y', strtotime($datetime));
}
