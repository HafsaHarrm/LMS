// Ledger LMS - shared front-end behavior

document.addEventListener('DOMContentLoaded', function () {

  // ---- Role picker on register page ----
  const roleChips = document.querySelectorAll('.role-chip');
  roleChips.forEach(chip => {
    chip.addEventListener('click', () => {
      roleChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      const input = chip.querySelector('input');
      if (input) input.checked = true;
    });
  });

  // ---- Generic modal open/close ----
  document.querySelectorAll('[data-open-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-open-modal');
      const modal = document.getElementById(id);
      if (modal) modal.classList.add('open');
    });
  });
  document.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.modal-backdrop').classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) backdrop.classList.remove('open');
    });
  });

  // ---- Confirm before destructive actions ----
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', function (e) {
      const msg = el.getAttribute('data-confirm') || 'Are you sure?';
      if (!confirm(msg)) e.preventDefault();
    });
  });

  // ---- Auto-dismiss flash alerts ----
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity .4s ease';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 400);
    }, 4500);
  });

  // ---- Live progress ring text sync (dashboards) ----
  document.querySelectorAll('.progress-fill').forEach(fill => {
    const pct = fill.getAttribute('data-pct') || 0;
    fill.style.width = pct + '%';
  });
});
