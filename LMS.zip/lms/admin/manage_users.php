<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$page_title = 'Manage Users — Ledger LMS';
$active = 'users';
$error = null; $success = null;

// Add user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if ($full_name === '' || $email === '' || $password === '') {
        $error = 'All fields are required.';
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $error = 'Email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $colors = ['#1B2A4A', '#2D6E5E', '#C4442C', '#E8A33D', '#4B2E9E'];
            $color = $colors[array_rand($colors)];
            $stmt = $conn->prepare("INSERT INTO users (full_name,email,password,role,avatar_color) VALUES (?,?,?,?,?)");
            $stmt->bind_param('sssss', $full_name, $email, $hash, $role, $color);
            $stmt->execute();
            $success = 'User created successfully.';
        }
    }
}

// Toggle suspend
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $conn->query("UPDATE users SET status = IF(status='active','suspended','active') WHERE id=$id AND role != 'admin'");
    header('Location: manage_users.php'); exit;
}

// Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM users WHERE id=$id AND role != 'admin'");
    header('Location: manage_users.php'); exit;
}

$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Administration</div><h1>Users</h1></div>
  <button class="btn btn-primary" data-open-modal="addUserModal">+ Add User</button>
</div>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

<div class="card">
  <table>
    <tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th><th></th></tr>
    <?php while ($u = $users->fetch_assoc()): ?>
    <tr>
      <td style="display:flex; align-items:center; gap:10px;">
        <span class="avatar" style="background:<?= e($u['avatar_color']) ?>"><?= e(initials($u['full_name'])) ?></span>
        <span><?= e($u['full_name']) ?><br><span class="muted" style="font-size:12px;"><?= e($u['email']) ?></span></span>
      </td>
      <td><span class="badge badge-<?= e($u['role']) ?>"><?= e($u['role']) ?></span></td>
      <td><span class="badge badge-<?= e($u['status']) ?>"><?= e($u['status']) ?></span></td>
      <td class="muted"><?= time_ago($u['created_at']) ?></td>
      <td style="white-space:nowrap;">
        <?php if ($u['role'] !== 'admin'): ?>
          <a href="?toggle=<?= $u['id'] ?>" class="btn btn-outline btn-sm"><?= $u['status'] === 'active' ? 'Suspend' : 'Activate' ?></a>
          <a href="?delete=<?= $u['id'] ?>" class="btn btn-danger btn-sm" data-confirm="Delete this user permanently?">Delete</a>
        <?php else: ?>
          <span class="muted">—</span>
        <?php endif; ?>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>

<div class="modal-backdrop" id="addUserModal">
  <div class="modal">
    <span class="close-x" data-close-modal>&times;</span>
    <h3>Add a new user</h3>
    <form method="POST">
      <label>Full name</label>
      <input type="text" name="full_name" required>
      <label>Email</label>
      <input type="email" name="email" required>
      <label>Password</label>
      <input type="password" name="password" required>
      <label>Role</label>
      <select name="role">
        <option value="student">Student</option>
        <option value="instructor">Instructor</option>
        <option value="admin">Admin</option>
      </select>
      <button type="submit" name="add_user" class="btn btn-primary btn-block" style="margin-top:20px;">Create User</button>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
