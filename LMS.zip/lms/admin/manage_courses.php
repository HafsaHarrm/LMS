<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$page_title = 'Manage Courses — Ledger LMS';
$active = 'courses';

if (isset($_GET['archive'])) {
    $id = (int)$_GET['archive'];
    $conn->query("UPDATE courses SET status = IF(status='archived','published','archived') WHERE id=$id");
    header('Location: manage_courses.php'); exit;
}
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM courses WHERE id=$id");
    header('Location: manage_courses.php'); exit;
}

$courses = $conn->query("SELECT c.*, u.full_name AS instructor,
    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id=c.id) AS enrolled,
    (SELECT COUNT(*) FROM lessons l WHERE l.course_id=c.id) AS lesson_count
    FROM courses c JOIN users u ON u.id=c.instructor_id ORDER BY c.created_at DESC");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Administration</div><h1>Courses</h1></div>
</div>

<div class="card">
  <table>
    <tr><th>Course</th><th>Instructor</th><th>Lessons</th><th>Enrolled</th><th>Status</th><th></th></tr>
    <?php while ($c = $courses->fetch_assoc()): ?>
    <tr>
      <td><strong><?= e($c['title']) ?></strong><br><span class="muted" style="font-size:12px;"><?= e($c['category']) ?></span></td>
      <td><?= e($c['instructor']) ?></td>
      <td><?= (int)$c['lesson_count'] ?></td>
      <td><?= (int)$c['enrolled'] ?></td>
      <td><span class="badge badge-<?= e($c['status']) ?>"><?= e($c['status']) ?></span></td>
      <td style="white-space:nowrap;">
        <a href="?archive=<?= $c['id'] ?>" class="btn btn-outline btn-sm"><?= $c['status'] === 'archived' ? 'Unarchive' : 'Archive' ?></a>
        <a href="?delete=<?= $c['id'] ?>" class="btn btn-danger btn-sm" data-confirm="Delete this course and all its content?">Delete</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
