<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$page_title = 'Admin Dashboard — Ledger LMS';
$active = 'dashboard';

$counts = [];
$counts['students']    = $conn->query("SELECT COUNT(*) c FROM users WHERE role='student'")->fetch_assoc()['c'];
$counts['instructors'] = $conn->query("SELECT COUNT(*) c FROM users WHERE role='instructor'")->fetch_assoc()['c'];
$counts['courses']     = $conn->query("SELECT COUNT(*) c FROM courses")->fetch_assoc()['c'];
$counts['enrollments'] = $conn->query("SELECT COUNT(*) c FROM enrollments")->fetch_assoc()['c'];

$recent_users = $conn->query("SELECT full_name, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 6");
$recent_courses = $conn->query("SELECT c.title, c.status, u.full_name AS instructor, c.created_at
    FROM courses c JOIN users u ON u.id = c.instructor_id ORDER BY c.created_at DESC LIMIT 6");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div>
    <div class="eyebrow">Ledger overview</div>
    <h1>Welcome back, <?= e(explode(' ', $_SESSION['name'])[0]) ?></h1>
  </div>
</div>

<div class="stat-grid">
  <div class="stat-card"><div class="num"><?= $counts['students'] ?></div><div class="label">Students</div></div>
  <div class="stat-card"><div class="num"><?= $counts['instructors'] ?></div><div class="label">Instructors</div></div>
  <div class="stat-card"><div class="num"><?= $counts['courses'] ?></div><div class="label">Courses</div></div>
  <div class="stat-card"><div class="num"><?= $counts['enrollments'] ?></div><div class="label">Enrollments</div></div>
</div>

<div class="two-col">
  <div class="card">
    <div class="card-header"><h3>Recently registered</h3><a href="manage_users.php" class="btn btn-outline btn-sm">Manage users</a></div>
    <table>
      <tr><th>Name</th><th>Role</th><th>Joined</th></tr>
      <?php while ($u = $recent_users->fetch_assoc()): ?>
      <tr>
        <td><?= e($u['full_name']) ?><br><span class="muted" style="font-size:12px;"><?= e($u['email']) ?></span></td>
        <td><span class="badge badge-<?= e($u['role']) ?>"><?= e($u['role']) ?></span></td>
        <td class="muted"><?= time_ago($u['created_at']) ?></td>
      </tr>
      <?php endwhile; ?>
    </table>
  </div>

  <div class="card">
    <div class="card-header"><h3>Recent courses</h3><a href="manage_courses.php" class="btn btn-outline btn-sm">Manage courses</a></div>
    <table>
      <tr><th>Course</th><th>Status</th></tr>
      <?php while ($c = $recent_courses->fetch_assoc()): ?>
      <tr>
        <td><?= e($c['title']) ?><br><span class="muted" style="font-size:12px;">by <?= e($c['instructor']) ?></span></td>
        <td><span class="badge badge-<?= e($c['status']) ?>"><?= e($c['status']) ?></span></td>
      </tr>
      <?php endwhile; ?>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
