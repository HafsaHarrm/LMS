<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('instructor');

$page_title = 'Instructor Dashboard — Ledger LMS';
$active = 'dashboard';
$uid = $_SESSION['user_id'];

$course_count = $conn->query("SELECT COUNT(*) c FROM courses WHERE instructor_id=$uid")->fetch_assoc()['c'];
$student_count = $conn->query("SELECT COUNT(DISTINCT e.student_id) c FROM enrollments e
    JOIN courses c ON c.id=e.course_id WHERE c.instructor_id=$uid")->fetch_assoc()['c'];
$pending_grading = $conn->query("SELECT COUNT(*) c FROM submissions s
    JOIN assignments a ON a.id=s.assignment_id
    JOIN courses c ON c.id=a.course_id
    WHERE c.instructor_id=$uid AND s.grade IS NULL")->fetch_assoc()['c'];
$lesson_count = $conn->query("SELECT COUNT(*) c FROM lessons l JOIN courses c ON c.id=l.course_id WHERE c.instructor_id=$uid")->fetch_assoc()['c'];

$courses = $conn->query("SELECT c.*, (SELECT COUNT(*) FROM enrollments e WHERE e.course_id=c.id) AS enrolled
    FROM courses c WHERE c.instructor_id=$uid ORDER BY c.created_at DESC LIMIT 4");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Instructor ledger</div><h1>Welcome back, <?= e(explode(' ', $_SESSION['name'])[0]) ?></h1></div>
  <a href="courses.php" class="btn btn-primary">+ New Course</a>
</div>

<div class="stat-grid">
  <div class="stat-card"><div class="num"><?= $course_count ?></div><div class="label">Courses</div></div>
  <div class="stat-card"><div class="num"><?= $student_count ?></div><div class="label">Students</div></div>
  <div class="stat-card"><div class="num"><?= $lesson_count ?></div><div class="label">Lessons</div></div>
  <div class="stat-card"><div class="num" style="color:var(--rust);"><?= $pending_grading ?></div><div class="label">Awaiting Grading</div></div>
</div>

<div class="section-title">Your courses</div>
<div class="course-grid">
  <?php if ($courses->num_rows === 0): ?>
    <div class="empty-state" style="grid-column: 1/-1;"><h3>No courses yet</h3><p>Create your first course to get started.</p></div>
  <?php endif; ?>
  <?php while ($c = $courses->fetch_assoc()): ?>
  <a href="course_detail.php?id=<?= $c['id'] ?>" class="course-card">
    <div class="cover" style="background:<?= e($c['cover_color']) ?>"><?= e($c['category']) ?></div>
    <div class="body">
      <h4><?= e($c['title']) ?></h4>
      <div class="desc"><?= e(mb_strimwidth($c['description'], 0, 90, '…')) ?></div>
      <div class="meta"><span><?= (int)$c['enrolled'] ?> enrolled</span><span class="badge badge-<?= e($c['status']) ?>"><?= e($c['status']) ?></span></div>
    </div>
  </a>
  <?php endwhile; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
