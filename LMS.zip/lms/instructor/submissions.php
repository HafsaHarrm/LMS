<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('instructor');

$page_title = 'Grading — Ledger LMS';
$active = 'submissions';
$uid = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['grade_submission'])) {
    $sub_id = (int)$_POST['submission_id'];
    $grade = (int)$_POST['grade'];
    $feedback = trim($_POST['feedback']);

    // verify this submission belongs to this instructor's course
    $check = $conn->query("SELECT s.id FROM submissions s
        JOIN assignments a ON a.id=s.assignment_id
        JOIN courses c ON c.id=a.course_id
        WHERE s.id=$sub_id AND c.instructor_id=$uid");
    if ($check->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE submissions SET grade=?, feedback=?, graded_at=NOW() WHERE id=?");
        $stmt->bind_param('isi', $grade, $feedback, $sub_id);
        $stmt->execute();
    }
    header('Location: submissions.php'); exit;
}

$filter = $_GET['filter'] ?? 'pending';
$where = $filter === 'pending' ? 'AND s.grade IS NULL' : ($filter === 'graded' ? 'AND s.grade IS NOT NULL' : '');

$subs = $conn->query("SELECT s.*, a.title AS a_title, a.max_points, c.title AS course_title, u.full_name AS student_name
    FROM submissions s
    JOIN assignments a ON a.id=s.assignment_id
    JOIN courses c ON c.id=a.course_id
    JOIN users u ON u.id=s.student_id
    WHERE c.instructor_id=$uid $where
    ORDER BY s.submitted_at DESC");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Instructor ledger</div><h1>Grading Queue</h1></div>
  <div style="display:flex; gap:8px;">
    <a href="?filter=pending" class="btn btn-sm <?= $filter==='pending'?'btn-primary':'btn-outline' ?>">Pending</a>
    <a href="?filter=graded" class="btn btn-sm <?= $filter==='graded'?'btn-primary':'btn-outline' ?>">Graded</a>
    <a href="?filter=all" class="btn btn-sm <?= $filter==='all'?'btn-primary':'btn-outline' ?>">All</a>
  </div>
</div>

<?php if ($subs->num_rows === 0): ?>
  <div class="empty-state"><h3>Nothing here</h3><p>No submissions match this filter.</p></div>
<?php endif; ?>

<?php while ($s = $subs->fetch_assoc()): ?>
<div class="card">
  <div class="card-header">
    <div>
      <h3><?= e($s['a_title']) ?></h3>
      <span class="muted" style="font-size:13px;"><?= e($s['course_title']) ?> · submitted by <strong><?= e($s['student_name']) ?></strong> · <?= time_ago($s['submitted_at']) ?></span>
    </div>
    <?= $s['grade'] !== null ? '<span class="badge badge-published">Graded '.(int)$s['grade'].'/'.(int)$s['max_points'].'</span>' : '<span class="badge badge-draft">Pending</span>' ?>
  </div>

  <?php if ($s['notes']): ?><p><?= nl2br(e($s['notes'])) ?></p><?php endif; ?>
  <?php if ($s['file_path']): ?>
    <p><a href="<?= base_url($s['file_path']) ?>" target="_blank" class="btn btn-outline btn-sm">&#128206; View submitted file</a></p>
  <?php endif; ?>

  <form method="POST" style="margin-top:12px; display:flex; gap:12px; align-items:flex-end; flex-wrap:wrap;">
    <input type="hidden" name="submission_id" value="<?= $s['id'] ?>">
    <div style="width:120px;">
      <label style="margin-top:0;">Grade (/<?= (int)$s['max_points'] ?>)</label>
      <input type="number" name="grade" min="0" max="<?= (int)$s['max_points'] ?>" value="<?= e($s['grade'] ?? '') ?>" required>
    </div>
    <div style="flex:1; min-width:200px;">
      <label style="margin-top:0;">Feedback</label>
      <input type="text" name="feedback" value="<?= e($s['feedback'] ?? '') ?>" placeholder="Optional feedback for the student">
    </div>
    <button type="submit" name="grade_submission" class="btn btn-primary">Save Grade</button>
  </form>
</div>
<?php endwhile; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
