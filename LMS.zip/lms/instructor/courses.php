<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('instructor');

$page_title = 'My Courses — Ledger LMS';
$active = 'courses';
$uid = $_SESSION['user_id'];
$error = null;

$palette = ['#1B2A4A', '#2D6E5E', '#C4442C', '#E8A33D', '#4B2E9E', '#0E7C86'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_course'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $category = trim($_POST['category']) ?: 'General';
    $status = $_POST['status'] === 'draft' ? 'draft' : 'published';

    if ($title === '') {
        $error = 'Course title is required.';
    } else {
        $color = $palette[array_rand($palette)];
        $stmt = $conn->prepare("INSERT INTO courses (instructor_id, title, description, category, cover_color, status) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('isssss', $uid, $title, $description, $category, $color, $status);
        $stmt->execute();
        header('Location: courses.php');
        exit;
    }
}

$courses = $conn->query("SELECT c.*, (SELECT COUNT(*) FROM enrollments e WHERE e.course_id=c.id) AS enrolled,
    (SELECT COUNT(*) FROM lessons l WHERE l.course_id=c.id) AS lesson_count
    FROM courses c WHERE c.instructor_id=$uid ORDER BY c.created_at DESC");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Instructor ledger</div><h1>My Courses</h1></div>
  <button class="btn btn-primary" data-open-modal="newCourseModal">+ New Course</button>
</div>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<div class="course-grid">
  <?php if ($courses->num_rows === 0): ?>
    <div class="empty-state" style="grid-column: 1/-1;"><h3>No courses yet</h3><p>Click "New Course" to publish your first one.</p></div>
  <?php endif; ?>
  <?php while ($c = $courses->fetch_assoc()): ?>
  <a href="course_detail.php?id=<?= $c['id'] ?>" class="course-card">
    <div class="cover" style="background:<?= e($c['cover_color']) ?>"><?= e($c['category']) ?></div>
    <div class="body">
      <h4><?= e($c['title']) ?></h4>
      <div class="desc"><?= e(mb_strimwidth($c['description'] ?: 'No description yet.', 0, 90, '…')) ?></div>
      <div class="meta"><span><?= (int)$c['lesson_count'] ?> lessons · <?= (int)$c['enrolled'] ?> enrolled</span>
      <span class="badge badge-<?= e($c['status']) ?>"><?= e($c['status']) ?></span></div>
    </div>
  </a>
  <?php endwhile; ?>
</div>

<div class="modal-backdrop" id="newCourseModal">
  <div class="modal">
    <span class="close-x" data-close-modal>&times;</span>
    <h3>Create a new course</h3>
    <form method="POST">
      <label>Title</label>
      <input type="text" name="title" required placeholder="e.g. Intro to Algorithms">
      <label>Description</label>
      <textarea name="description" placeholder="What will students learn?"></textarea>
      <label>Category</label>
      <input type="text" name="category" placeholder="e.g. Programming">
      <label>Status</label>
      <select name="status">
        <option value="published">Published (visible to students)</option>
        <option value="draft">Draft (hidden for now)</option>
      </select>
      <button type="submit" name="create_course" class="btn btn-primary btn-block" style="margin-top:20px;">Create Course</button>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
