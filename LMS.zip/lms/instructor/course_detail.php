<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('instructor');

$uid = $_SESSION['user_id'];
$course_id = (int)($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM courses WHERE id=? AND instructor_id=?");
$stmt->bind_param('ii', $course_id, $uid);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();
if (!$course) { header('Location: courses.php'); exit; }

$page_title = e($course['title']) . ' — Ledger LMS';
$active = 'courses';
$error = null;

// Add lesson
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_lesson'])) {
    $title = trim($_POST['lesson_title']);
    $content = trim($_POST['lesson_content']);
    $video = trim($_POST['video_url']);
    if ($title === '') {
        $error = 'Lesson title is required.';
    } else {
        $pos = (int)$conn->query("SELECT COALESCE(MAX(position),0)+1 p FROM lessons WHERE course_id=$course_id")->fetch_assoc()['p'];
        $stmt = $conn->prepare("INSERT INTO lessons (course_id,title,content,video_url,position) VALUES (?,?,?,?,?)");
        $stmt->bind_param('isssi', $course_id, $title, $content, $video, $pos);
        $stmt->execute();
        header("Location: course_detail.php?id=$course_id"); exit;
    }
}

// Add assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_assignment'])) {
    $title = trim($_POST['a_title']);
    $instructions = trim($_POST['a_instructions']);
    $due = $_POST['due_date'] ?: null;
    $points = (int)($_POST['max_points'] ?: 100);
    if ($title === '') {
        $error = 'Assignment title is required.';
    } else {
        $stmt = $conn->prepare("INSERT INTO assignments (course_id,title,instructions,due_date,max_points) VALUES (?,?,?,?,?)");
        $stmt->bind_param('isssi', $course_id, $title, $instructions, $due, $points);
        $stmt->execute();
        header("Location: course_detail.php?id=$course_id"); exit;
    }
}

// Post announcement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_announcement'])) {
    $title = trim($_POST['ann_title']);
    $body = trim($_POST['ann_body']);
    if ($title !== '' && $body !== '') {
        $stmt = $conn->prepare("INSERT INTO announcements (course_id,title,body) VALUES (?,?,?)");
        $stmt->bind_param('iss', $course_id, $title, $body);
        $stmt->execute();
        header("Location: course_detail.php?id=$course_id"); exit;
    }
}

// Delete lesson / assignment
if (isset($_GET['delete_lesson'])) {
    $lid = (int)$_GET['delete_lesson'];
    $conn->query("DELETE FROM lessons WHERE id=$lid AND course_id=$course_id");
    header("Location: course_detail.php?id=$course_id"); exit;
}
if (isset($_GET['delete_assignment'])) {
    $aid = (int)$_GET['delete_assignment'];
    $conn->query("DELETE FROM assignments WHERE id=$aid AND course_id=$course_id");
    header("Location: course_detail.php?id=$course_id"); exit;
}

$lessons = $conn->query("SELECT * FROM lessons WHERE course_id=$course_id ORDER BY position ASC");
$assignments = $conn->query("SELECT a.*, (SELECT COUNT(*) FROM submissions s WHERE s.assignment_id=a.id) AS sub_count
    FROM assignments a WHERE a.course_id=$course_id ORDER BY a.due_date ASC");
$students = $conn->query("SELECT u.full_name, u.email, e.progress, e.enrolled_at FROM enrollments e
    JOIN users u ON u.id=e.student_id WHERE e.course_id=$course_id ORDER BY e.enrolled_at DESC");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div>
    <div class="eyebrow"><?= e($course['category']) ?> · <span class="badge badge-<?= e($course['status']) ?>"><?= e($course['status']) ?></span></div>
    <h1><?= e($course['title']) ?></h1>
    <p class="muted" style="max-width:640px;"><?= e($course['description']) ?></p>
  </div>
  <a href="courses.php" class="btn btn-outline">&larr; Back to courses</a>
</div>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<div class="two-col">
  <div>
    <div class="card">
      <div class="card-header">
        <h3>Lessons</h3>
        <button class="btn btn-amber btn-sm" data-open-modal="lessonModal">+ Add Lesson</button>
      </div>
      <div class="ledger-list">
        <?php if ($lessons->num_rows === 0): ?>
          <div class="empty-state"><p>No lessons yet. Add the first one to build your syllabus.</p></div>
        <?php endif; ?>
        <?php $n = 1; while ($l = $lessons->fetch_assoc()): ?>
        <div class="ledger-item">
          <div class="tab"><?= str_pad($n++, 2, '0', STR_PAD_LEFT) ?></div>
          <div class="content">
            <h4><?= e($l['title']) ?></h4>
            <p><?= e(mb_strimwidth($l['content'] ?? '', 0, 110, '…')) ?></p>
          </div>
          <div class="actions">
            <a href="?id=<?= $course_id ?>&delete_lesson=<?= $l['id'] ?>" class="btn btn-danger btn-sm" data-confirm="Delete this lesson?">Delete</a>
          </div>
        </div>
        <?php endwhile; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h3>Assignments</h3>
        <button class="btn btn-amber btn-sm" data-open-modal="assignmentModal">+ Add Assignment</button>
      </div>
      <table>
        <tr><th>Title</th><th>Due</th><th>Points</th><th>Submissions</th><th></th></tr>
        <?php if ($assignments->num_rows === 0): ?>
          <tr><td colspan="5" class="muted">No assignments yet.</td></tr>
        <?php endif; ?>
        <?php while ($a = $assignments->fetch_assoc()): ?>
        <tr>
          <td><?= e($a['title']) ?></td>
          <td class="muted"><?= $a['due_date'] ? date('M j, Y', strtotime($a['due_date'])) : '—' ?></td>
          <td><?= (int)$a['max_points'] ?></td>
          <td><?= (int)$a['sub_count'] ?></td>
          <td><a href="?id=<?= $course_id ?>&delete_assignment=<?= $a['id'] ?>" class="btn btn-danger btn-sm" data-confirm="Delete this assignment?">Delete</a></td>
        </tr>
        <?php endwhile; ?>
      </table>
    </div>

    <div class="card">
      <div class="card-header"><h3>Post an announcement</h3></div>
      <form method="POST">
        <label>Title</label>
        <input type="text" name="ann_title" required>
        <label>Message</label>
        <textarea name="ann_body" required></textarea>
        <button type="submit" name="post_announcement" class="btn btn-primary" style="margin-top:16px;">Post to Students</button>
      </form>
    </div>
  </div>

  <div>
    <div class="card">
      <div class="card-header"><h3>Enrolled Students (<?= $students->num_rows ?>)</h3></div>
      <?php if ($students->num_rows === 0): ?>
        <p class="muted">No students enrolled yet.</p>
      <?php endif; ?>
      <?php while ($s = $students->fetch_assoc()): ?>
        <div style="padding:10px 0; border-bottom:1px dashed var(--line);">
          <div style="display:flex; justify-content:space-between;">
            <strong style="font-size:14px;"><?= e($s['full_name']) ?></strong>
            <span class="muted" style="font-size:12.5px;"><?= (int)$s['progress'] ?>%</span>
          </div>
          <div class="progress-track" style="margin-top:6px;"><div class="progress-fill" data-pct="<?= (int)$s['progress'] ?>"></div></div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</div>

<div class="modal-backdrop" id="lessonModal">
  <div class="modal">
    <span class="close-x" data-close-modal>&times;</span>
    <h3>Add a lesson</h3>
    <form method="POST">
      <label>Title</label>
      <input type="text" name="lesson_title" required>
      <label>Content</label>
      <textarea name="lesson_content" placeholder="Lesson notes or description"></textarea>
      <label>Video URL (optional)</label>
      <input type="url" name="video_url" placeholder="https://...">
      <button type="submit" name="add_lesson" class="btn btn-primary btn-block" style="margin-top:20px;">Add Lesson</button>
    </form>
  </div>
</div>

<div class="modal-backdrop" id="assignmentModal">
  <div class="modal">
    <span class="close-x" data-close-modal>&times;</span>
    <h3>Add an assignment</h3>
    <form method="POST">
      <label>Title</label>
      <input type="text" name="a_title" required>
      <label>Instructions</label>
      <textarea name="a_instructions"></textarea>
      <label>Due date</label>
      <input type="date" name="due_date">
      <label>Max points</label>
      <input type="number" name="max_points" value="100">
      <button type="submit" name="add_assignment" class="btn btn-primary btn-block" style="margin-top:20px;">Add Assignment</button>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
