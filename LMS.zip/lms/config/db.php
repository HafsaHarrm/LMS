<?php
/**
 * Database connection
 * Update these 4 values to match your MySQL Workbench / XAMPP / WAMP setup.
 */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'Harrm$1004'); 
define('DB_PORT', '3307'); 
         // set your MySQL root password if you have one
define('DB_NAME', 'lms_db');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error .
        '<br>Make sure MySQL is running and that you imported database/lms.sql');
}

$conn->set_charset('utf8mb4');
