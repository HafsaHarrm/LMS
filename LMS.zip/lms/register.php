<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    header('Location: ' . current_role() . '/dashboard.php');
    exit;
}

$error = null;
$colors = ['#1B2A4A', '#2D6E5E', '#C4442C', '#E8A33D', '#4B2E9E'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $role      = $_POST['role'] ?? 'student';

    if (!in_array($role, ['student', 'instructor'], true)) {
        $role = 'student'; // only student/instructor can self-register; admin is seeded
    }

    if ($full_name === '' || $email === '' || $password === '') {
        $error = 'All fields are required.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $error = 'An account with that email already exists.';
        }
        $stmt->close();

        if (!$error) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $color = $colors[array_rand($colors)];
            $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, role, avatar_color) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param('sssss', $full_name, $email, $hash, $role, $color);
            if ($stmt->execute()) {
                flash('success', 'Account created! You can sign in now.');
                header('Location: index.php');
                exit;
            } else {
                $error = 'Something went wrong. Please try again.';
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create account — Ledger LMS</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-shell">
  <div class="auth-visual">
    <div class="brand">Ledger LMS</div>
    <div class="pitch">
      <h1>Open a new page in your learning record.</h1>
      <p>Register as a student to enroll in courses, or as an instructor to publish your own. Every account keeps its own ledger of progress.</p>
    </div>
    <div class="tabline">
      <div><strong>01</strong>Register</div>
      <div><strong>02</strong>Pick a role</div>
      <div><strong>03</strong>Start</div>
    </div>
  </div>
  <div class="auth-form-side">
    <div class="auth-card">
      <div class="eyebrow">Get started</div>
      <h2>Create your account</h2>

      <?php if ($error): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
      <?php endif; ?>

      <form method="POST" action="register.php">
        <label for="full_name">Full name</label>
        <input type="text" id="full_name" name="full_name" placeholder="Jordan Reyes" required value="<?= e($_POST['full_name'] ?? '') ?>">

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="you@ledger.edu" required value="<?= e($_POST['email'] ?? '') ?>">

        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="At least 6 characters" required>

        <label>I am a...</label>
        <div class="role-picker">
          <label class="role-chip active">
            <input type="radio" name="role" value="student" checked> Student
          </label>
          <label class="role-chip">
            <input type="radio" name="role" value="instructor"> Instructor
          </label>
        </div>

        <button type="submit" class="btn btn-primary btn-block" style="margin-top:22px;">Create Account</button>
      </form>

      <div class="switch-link">Already have an account? <a href="index.php">Sign in</a></div>
    </div>
  </div>
</div>
<script src="assets/js/script.js"></script>
</body>
</html>
