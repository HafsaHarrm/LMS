<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$uid = $_SESSION['user_id'];
$course_id = (int)($_GET['id'] ?? 0);

// Confirm enrollment
$stmt = $conn->prepare("SELECT c.*, e.progress, u.full_name AS instructor FROM enrollments e
    JOIN courses c ON c.id=e.course_id JOIN users u ON u.id=c.instructor_id
    WHERE e.course_id=? AND e.student_id=?");
$stmt->bind_param('ii', $course_id, $uid);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();
if (!$course) { header('Location: browse_courses.php'); exit; }

if (isset($_GET['complete'])) {
    $lid = (int)$_GET['complete'];
    $stmt = $conn->prepare("INSERT IGNORE INTO lesson_completions (student_id, lesson_id) VALUES (?,?)");
    $stmt->bind_param('ii', $uid, $lid);
    $stmt->execute();
    recalc_progress($conn, $uid, $course_id);
    header("Location: course_view.php?id=$course_id"); exit;
}

$page_title = e($course['title']) . ' — Ledger LMS';
$active = 'mycourses';

$lessons = $conn->query("SELECT l.*, EXISTS(
        SELECT 1 FROM lesson_completions lc WHERE lc.lesson_id=l.id AND lc.student_id=$uid
    ) AS done FROM lessons l WHERE l.course_id=$course_id ORDER BY l.position ASC");

$announcements = $conn->query("SELECT * FROM announcements WHERE course_id=$course_id ORDER BY created_at DESC LIMIT 5");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div>
    <div class="eyebrow"><?= e($course['category']) ?> · by <?= e($course['instructor']) ?></div>
    <h1><?= e($course['title']) ?></h1>
  </div>
  <a href="my_courses.php" class="btn btn-outline">&larr; My Courses</a>
</div>

<div class="card" style="max-width:420px;">
  <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
    <strong>Your progress</strong><span><?= (int)$course['progress'] ?>%</span>
  </div>
  <div class="progress-track"><div class="progress-fill" data-pct="<?= (int)$course['progress'] ?>"></div></div>
</div>

<div class="two-col">
  <div>
    <div class="card">
      <div class="card-header"><h3>Lessons</h3></div>
      <div class="ledger-list">
        <?php if ($lessons->num_rows === 0): ?>
          <div class="empty-state"><p>No lessons published yet.</p></div>
        <?php endif; ?>
        <?php $n = 1; while ($l = $lessons->fetch_assoc()): ?>
        <div class="ledger-item <?= $l['done'] ? 'done' : '' ?>">
          <div class="tab"><?= $l['done'] ? '&#10003;' : str_pad($n, 2, '0', STR_PAD_LEFT) ?></div>
          <div class="content">
            <h4><?= e($l['title']) ?></h4>
            <p><?= nl2br(e($l['content'])) ?></p>
            <?php if ($l['video_url']): ?>
              <p><a href="<?= e($l['video_url']) ?>" target="_blank" class="muted">&#9654; Watch video</a></p>
            <?php endif; ?>
          </div>
          <div class="actions">
            <?php if (!$l['done']): ?>
              <a href="?id=<?= $course_id ?>&complete=<?= $l['id'] ?>" class="btn btn-teal btn-sm">Mark Complete</a>
            <?php else: ?>
              <span class="badge badge-published">Done</span>
            <?php endif; ?>
          </div>
        </div>
        <?php $n++; endwhile; ?>
      </div>
    </div>
  </div>

  <div>
    <div class="card">
      <div class="card-header"><h3>Announcements</h3></div>
      <?php if ($announcements->num_rows === 0): ?>
        <p class="muted">No announcements yet.</p>
      <?php endif; ?>
      <?php while ($a = $announcements->fetch_assoc()): ?>
        <div style="padding:10px 0; border-bottom:1px dashed var(--line);">
          <strong style="font-size:14px;"><?= e($a['title']) ?></strong>
          <p style="font-size:13.5px; margin:4px 0 2px;"><?= nl2br(e($a['body'])) ?></p>
          <span class="muted" style="font-size:12px;"><?= time_ago($a['created_at']) ?></span>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
