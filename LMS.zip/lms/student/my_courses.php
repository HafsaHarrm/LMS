<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$page_title = 'My Courses — Ledger LMS';
$active = 'mycourses';
$uid = $_SESSION['user_id'];

$courses = $conn->query("SELECT c.*, e.progress, u.full_name AS instructor
    FROM enrollments e JOIN courses c ON c.id=e.course_id JOIN users u ON u.id=c.instructor_id
    WHERE e.student_id=$uid ORDER BY e.enrolled_at DESC");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Student ledger</div><h1>My Courses</h1></div>
  <a href="browse_courses.php" class="btn btn-primary">+ Enroll in more</a>
</div>

<div class="course-grid">
  <?php if ($courses->num_rows === 0): ?>
    <div class="empty-state" style="grid-column:1/-1;"><h3>No enrollments yet</h3><p>Browse the catalog to get started.</p></div>
  <?php endif; ?>
  <?php while ($c = $courses->fetch_assoc()): ?>
  <a href="course_view.php?id=<?= $c['id'] ?>" class="course-card">
    <div class="cover" style="background:<?= e($c['cover_color']) ?>"><?= e($c['category']) ?></div>
    <div class="body">
      <h4><?= e($c['title']) ?></h4>
      <div class="desc">by <?= e($c['instructor']) ?></div>
      <div class="progress-track" style="margin-top:auto;"><div class="progress-fill" data-pct="<?= (int)$c['progress'] ?>"></div></div>
      <div class="meta" style="margin-top:6px;"><span><?= (int)$c['progress'] ?>% complete</span></div>
    </div>
  </a>
  <?php endwhile; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
