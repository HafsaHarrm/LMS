<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$page_title = 'Browse Courses — Ledger LMS';
$active = 'browse';
$uid = $_SESSION['user_id'];

if (isset($_GET['enroll'])) {
    $cid = (int)$_GET['enroll'];
    $stmt = $conn->prepare("INSERT IGNORE INTO enrollments (student_id, course_id) VALUES (?,?)");
    $stmt->bind_param('ii', $uid, $cid);
    $stmt->execute();
    header('Location: course_view.php?id=' . $cid); exit;
}

$search = trim($_GET['q'] ?? '');
$sql = "SELECT c.*, u.full_name AS instructor,
        (SELECT COUNT(*) FROM lessons l WHERE l.course_id=c.id) AS lesson_count,
        EXISTS(SELECT 1 FROM enrollments e WHERE e.course_id=c.id AND e.student_id=$uid) AS is_enrolled
        FROM courses c JOIN users u ON u.id=c.instructor_id
        WHERE c.status='published'";
if ($search !== '') {
    $esc = $conn->real_escape_string($search);
    $sql .= " AND (c.title LIKE '%$esc%' OR c.category LIKE '%$esc%')";
}
$sql .= " ORDER BY c.created_at DESC";
$courses = $conn->query($sql);

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Catalog</div><h1>Browse Courses</h1></div>
</div>

<form method="GET" style="margin-bottom:22px; max-width:420px;">
  <input type="text" name="q" placeholder="Search by title or category…" value="<?= e($search) ?>">
</form>

<div class="course-grid">
  <?php if ($courses->num_rows === 0): ?>
    <div class="empty-state" style="grid-column:1/-1;"><h3>No courses found</h3><p>Try a different search.</p></div>
  <?php endif; ?>
  <?php while ($c = $courses->fetch_assoc()): ?>
  <div class="course-card">
    <div class="cover" style="background:<?= e($c['cover_color']) ?>"><?= e($c['category']) ?></div>
    <div class="body">
      <h4><?= e($c['title']) ?></h4>
      <div class="desc"><?= e(mb_strimwidth($c['description'] ?: 'No description yet.', 0, 90, '…')) ?></div>
      <div class="meta"><span><?= (int)$c['lesson_count'] ?> lessons</span><span>by <?= e($c['instructor']) ?></span></div>
      <?php if ($c['is_enrolled']): ?>
        <a href="course_view.php?id=<?= $c['id'] ?>" class="btn btn-outline btn-block">Continue</a>
      <?php else: ?>
        <a href="?enroll=<?= $c['id'] ?>" class="btn btn-primary btn-block">Enroll</a>
      <?php endif; ?>
    </div>
  </div>
  <?php endwhile; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
