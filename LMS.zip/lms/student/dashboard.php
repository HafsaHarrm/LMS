<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$page_title = 'My Dashboard — Ledger LMS';
$active = 'dashboard';
$uid = $_SESSION['user_id'];

$enrolled_count = $conn->query("SELECT COUNT(*) c FROM enrollments WHERE student_id=$uid")->fetch_assoc()['c'];
$avg_progress = $conn->query("SELECT COALESCE(AVG(progress),0) a FROM enrollments WHERE student_id=$uid")->fetch_assoc()['a'];
$pending_assignments = $conn->query("SELECT COUNT(*) c FROM assignments a
    JOIN enrollments e ON e.course_id=a.course_id AND e.student_id=$uid
    LEFT JOIN submissions s ON s.assignment_id=a.id AND s.student_id=$uid
    WHERE s.id IS NULL")->fetch_assoc()['c'];
$graded_count = $conn->query("SELECT COUNT(*) c FROM submissions WHERE student_id=$uid AND grade IS NOT NULL")->fetch_assoc()['c'];

$courses = $conn->query("SELECT c.*, e.progress, u.full_name AS instructor
    FROM enrollments e JOIN courses c ON c.id=e.course_id JOIN users u ON u.id=c.instructor_id
    WHERE e.student_id=$uid ORDER BY e.enrolled_at DESC LIMIT 4");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Student ledger</div><h1>Welcome back, <?= e(explode(' ', $_SESSION['name'])[0]) ?></h1></div>
  <a href="browse_courses.php" class="btn btn-primary">Browse Courses</a>
</div>

<div class="stat-grid">
  <div class="stat-card"><div class="num"><?= $enrolled_count ?></div><div class="label">Enrolled Courses</div></div>
  <div class="stat-card"><div class="num"><?= round($avg_progress) ?>%</div><div class="label">Avg. Progress</div></div>
  <div class="stat-card"><div class="num" style="color:var(--rust);"><?= $pending_assignments ?></div><div class="label">Assignments Due</div></div>
  <div class="stat-card"><div class="num"><?= $graded_count ?></div><div class="label">Graded Submissions</div></div>
</div>

<div class="section-title">Continue learning</div>
<div class="course-grid">
  <?php if ($courses->num_rows === 0): ?>
    <div class="empty-state" style="grid-column:1/-1;"><h3>You're not enrolled anywhere yet</h3><p>Browse the catalog to start your first course.</p></div>
  <?php endif; ?>
  <?php while ($c = $courses->fetch_assoc()): ?>
  <a href="course_view.php?id=<?= $c['id'] ?>" class="course-card">
    <div class="cover" style="background:<?= e($c['cover_color']) ?>"><?= e($c['category']) ?></div>
    <div class="body">
      <h4><?= e($c['title']) ?></h4>
      <div class="desc">by <?= e($c['instructor']) ?></div>
      <div class="progress-track" style="margin-top:auto;"><div class="progress-fill" data-pct="<?= (int)$c['progress'] ?>"></div></div>
      <div class="meta" style="margin-top:6px;"><span><?= (int)$c['progress'] ?>% complete</span></div>
    </div>
  </a>
  <?php endwhile; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
