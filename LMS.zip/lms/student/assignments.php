<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$page_title = 'Assignments — Ledger LMS';
$active = 'assignments';
$uid = $_SESSION['user_id'];
$error = null;

// Handle submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_assignment'])) {
    $assignment_id = (int)$_POST['assignment_id'];
    $notes = trim($_POST['notes']);

    // Verify student is enrolled in the course that owns this assignment
    $check = $conn->query("SELECT a.id FROM assignments a JOIN enrollments e ON e.course_id=a.course_id
        WHERE a.id=$assignment_id AND e.student_id=$uid");
    if ($check->num_rows === 0) {
        $error = 'You are not enrolled in this course.';
    } else {
        $file_path = null;
        if (!empty($_FILES['submission_file']['name'])) {
            $uploadDir = __DIR__ . '/../uploads/assignments/';
            $safeName = time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $_FILES['submission_file']['name']);
            if (move_uploaded_file($_FILES['submission_file']['tmp_name'], $uploadDir . $safeName)) {
                $file_path = 'uploads/assignments/' . $safeName;
            }
        }
        $stmt = $conn->prepare("INSERT INTO submissions (assignment_id, student_id, file_path, notes)
            VALUES (?,?,?,?)
            ON DUPLICATE KEY UPDATE file_path=VALUES(file_path), notes=VALUES(notes), submitted_at=NOW(), grade=NULL, feedback=NULL");
        $stmt->bind_param('iiss', $assignment_id, $uid, $file_path, $notes);
        $stmt->execute();
        header('Location: assignments.php'); exit;
    }
}

$assignments = $conn->query("SELECT a.*, c.title AS course_title, s.grade, s.feedback, s.submitted_at, s.notes AS sub_notes
    FROM assignments a
    JOIN enrollments e ON e.course_id=a.course_id AND e.student_id=$uid
    JOIN courses c ON c.id=a.course_id
    LEFT JOIN submissions s ON s.assignment_id=a.id AND s.student_id=$uid
    ORDER BY (s.id IS NOT NULL), a.due_date ASC");

include __DIR__ . '/../includes/header.php';
?>
<div class="topbar">
  <div><div class="eyebrow">Student ledger</div><h1>Assignments</h1></div>
</div>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<?php if ($assignments->num_rows === 0): ?>
  <div class="empty-state"><h3>No assignments yet</h3><p>Enroll in a course to see its assignments here.</p></div>
<?php endif; ?>

<?php while ($a = $assignments->fetch_assoc()): ?>
<div class="card">
  <div class="card-header">
    <div>
      <h3><?= e($a['title']) ?></h3>
      <span class="muted" style="font-size:13px;"><?= e($a['course_title']) ?> ·
        <?= $a['due_date'] ? 'Due ' . date('M j, Y', strtotime($a['due_date'])) : 'No due date' ?>
        · <?= (int)$a['max_points'] ?> pts</span>
    </div>
    <?php if ($a['grade'] !== null): ?>
      <span class="badge badge-published">Graded <?= (int)$a['grade'] ?>/<?= (int)$a['max_points'] ?></span>
    <?php elseif ($a['submitted_at']): ?>
      <span class="badge badge-draft">Submitted — awaiting grade</span>
    <?php else: ?>
      <span class="badge badge-suspended">Not submitted</span>
    <?php endif; ?>
  </div>
  <p><?= nl2br(e($a['instructions'])) ?></p>

  <?php if ($a['feedback']): ?>
    <div class="alert alert-info"><strong>Instructor feedback:</strong> <?= e($a['feedback']) ?></div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data" style="margin-top:10px;">
    <input type="hidden" name="assignment_id" value="<?= $a['id'] ?>">
    <label style="margin-top:0;">Notes (optional)</label>
    <textarea name="notes" placeholder="Comments for your instructor"><?= e($a['sub_notes'] ?? '') ?></textarea>
    <label>Attach file (optional)</label>
    <input type="file" name="submission_file">
    <button type="submit" name="submit_assignment" class="btn btn-primary" style="margin-top:14px;">
      <?= $a['submitted_at'] ? 'Resubmit' : 'Submit Assignment' ?>
    </button>
  </form>
</div>
<?php endwhile; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
