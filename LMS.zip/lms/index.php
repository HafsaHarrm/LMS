<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    header('Location: ' . current_role() . '/dashboard.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, email, password, role, avatar_color, status FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$user || !password_verify($password, $user['password'])) {
            $error = 'Incorrect email or password.';
        } elseif ($user['status'] === 'suspended') {
            $error = 'This account has been suspended. Contact an administrator.';
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['full_name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['avatar_color'] = $user['avatar_color'];
            header('Location: ' . $user['role'] . '/dashboard.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign in — Ledger LMS</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-shell">
  <div class="auth-visual">
    <div class="brand">Ledger LMS</div>
    <div class="pitch">
      <h1>Every course, kept like a ledger — ordered, dated, accounted for.</h1>
      <p>Instructors publish lessons and assignments in sequence. Students work through them and see exactly where they stand. Nothing gets lost between the lines.</p>
    </div>
    <div class="tabline">
      <div><strong>01</strong>Enroll</div>
      <div><strong>02</strong>Learn</div>
      <div><strong>03</strong>Submit</div>
      <div><strong>04</strong>Get graded</div>
    </div>
  </div>
  <div class="auth-form-side">
    <div class="auth-card">
      <div class="eyebrow">Welcome back</div>
      <h2>Sign in to your account</h2>

      <?php if ($error): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
      <?php endif; ?>

      <form method="POST" action="index.php">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="you@ledger.edu" required value="<?= e($_POST['email'] ?? '') ?>">

        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="••••••••" required>

        <button type="submit" class="btn btn-primary btn-block" style="margin-top:22px;">Sign In</button>
      </form>

      <div class="switch-link">Don't have an account? <a href="register.php">Register here</a></div>

      <!-- <div class="alert alert-info" style="margin-top:24px;">
        <strong>Demo accounts</strong> (password: <code>password123</code>)<br>
        admin@ledger.edu · instructor@ledger.edu · student@ledger.edu
      </div> -->
    </div>
  </div>
</div>
</body>
</html>
